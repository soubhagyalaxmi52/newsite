import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AboutSection from './components/AboutSection';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Testimonials from './components/Testimonials';
import StatsSection from './components/StatsSection';
import CallToAction from './components/CallToAction';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import EmergencyBanner from './components/EmergencyBanner';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <EmergencyBanner />
      <Navbar />
      <Hero />
      <AboutSection />
      <Services />
      <WhyChooseUs />
      <StatsSection />
      <Testimonials />
      <CallToAction />
      <ContactForm />
      <Footer />
    </div>
  );
}

export default App;