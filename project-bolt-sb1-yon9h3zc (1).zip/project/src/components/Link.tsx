import React from 'react';

interface LinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Link: React.FC<LinkProps> = ({ 
  href, 
  children, 
  className = '', 
  onClick 
}) => {
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Simulate navigate to the new page by scrolling to the appropriate section
    const element = document.getElementById(href.replace('/', '')) || document.getElementById('root');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    
    if (onClick) onClick();
  };
  
  return (
    <a 
      href={href}
      className={className}
      onClick={handleClick}
    >
      {children}
    </a>
  );
};