import React from 'react';
import { Shield, Clock, Heart, Award, Stethoscope, CheckSquare } from 'lucide-react';

const WhyChooseUs: React.FC = () => {
  const reasons = [
    {
      icon: <Shield size={40} className="text-primary" />,
      title: "Licensed & Certified",
      description: "All our healthcare professionals are fully licensed, insured, and certified in their respective fields."
    },
    {
      icon: <Heart size={40} className="text-primary" />,
      title: "Compassionate Care",
      description: "We approach each patient with empathy and respect, focusing on both physical and emotional well-being."
    },
    {
      icon: <Clock size={40} className="text-primary" />,
      title: "24/7 Availability",
      description: "Our care services are available around the clock, ensuring help is always at hand when you need it."
    },
    {
      icon: <CheckSquare size={40} className="text-primary" />,
      title: "Personalized Approach",
      description: "We develop individualized care plans tailored to each patient's specific health needs and preferences."
    },
    {
      icon: <Stethoscope size={40} className="text-primary" />,
      title: "Clinical Excellence",
      description: "Our team follows the highest standards of clinical practice, updated with the latest medical advancements."
    },
    {
      icon: <Award size={40} className="text-primary" />,
      title: "Proven Results",
      description: "We've helped hundreds of patients recover faster and maintain better health outcomes at home."
    }
  ];

  return (
    <div className="py-16 bg-blue-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose CareComfort</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We stand out through our commitment to excellence, compassion, and personalized care.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div className="mb-4">
                {reason.icon}
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {reason.title}
              </h3>
              
              <p className="text-gray-600">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WhyChooseUs;