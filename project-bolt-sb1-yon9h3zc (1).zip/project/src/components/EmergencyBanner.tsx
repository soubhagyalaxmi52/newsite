import React from 'react';
import { AlertTriangle, PhoneCall } from 'lucide-react';

const EmergencyBanner: React.FC = () => {
  return (
    <div className="bg-red-600 text-white py-3 px-4">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-2 md:mb-0">
          <AlertTriangle size={20} className="mr-2" />
          <span className="font-medium">Emergency Medical Support Available 24/7</span>
        </div>
        
        <a 
          href="tel:+919876543210" 
          className="flex items-center font-medium bg-white text-red-600 px-4 py-1 rounded-full hover:bg-red-100 transition-colors"
        >
          <PhoneCall size={16} className="mr-1" />
          +91 98765 43210
        </a>
      </div>
    </div>
  );
};

export default EmergencyBanner;