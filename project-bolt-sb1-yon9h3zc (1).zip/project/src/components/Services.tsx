import React from 'react';
import ServiceCard from './ServiceCard';
import { Heart, Users, Hospital, Activity, ActivitySquare } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      title: "In-Home Nursing",
      description: "Our certified nurses provide medical care at home, including medication administration, wound care, and health monitoring.",
      icon: <Hospital size={24} className="text-primary" />,
      image: "https://images.pexels.com/photos/7551808/pexels-photo-7551808.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      title: "Elder Care",
      description: "Dedicated support for seniors, focusing on daily activities, companionship, and overall well-being.",
      icon: <Users size={24} className="text-primary" />,
      image: "https://images.pexels.com/photos/7551741/pexels-photo-7551741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      title: "Post-Hospitalization Support",
      description: "Assistance with recovery after hospital discharge, ensuring a smooth transition and continuous care.",
      icon: <Heart size={24} className="text-primary" />,
      image: "https://images.pexels.com/photos/7615574/pexels-photo-7615574.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      title: "Physiotherapy",
      description: "Professional physiotherapy sessions at home to aid in rehabilitation and mobility improvement.",
      icon: <Activity size={24} className="text-primary" />,
      image: "https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      title: "Chronic Illness Management",
      description: "Comprehensive care plans for managing chronic conditions, tailored to individual needs.",
      icon: <ActivitySquare size={24} className="text-primary" />,
      image: "https://images.pexels.com/photos/7659863/pexels-photo-7659863.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];

  return (
    <div id="services" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer a range of specialized healthcare services, delivered with compassion and expertise right to your home.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
              image={service.image}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;