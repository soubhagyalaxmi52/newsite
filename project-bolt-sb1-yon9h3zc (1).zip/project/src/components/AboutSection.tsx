import React from 'react';
import { CheckCircle2 } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <div id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image with overlay */}
          <div className="relative rounded-xl overflow-hidden h-[500px]">
            <img 
              src="https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Healthcare professional with patient" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/80 to-transparent p-8">
              <p className="text-white text-xl font-medium">
                "We believe healthcare should be personalized, compassionate, and accessible to all."
              </p>
            </div>
          </div>
          
          {/* Content */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">About CareComfort</h2>
            
            <p className="text-gray-700 mb-6">
              Founded in 2018, CareComfort has been providing exceptional in-home healthcare services to families across Odisha. Our mission is to deliver professional medical care with a personal touch, allowing patients to recover and thrive in the comfort of their own homes.
            </p>
            
            <p className="text-gray-700 mb-8">
              Our team consists of certified nurses, trained caregivers, and experienced physiotherapists who are passionate about improving the quality of life for our patients. We believe that healing happens best in familiar surroundings, and we're committed to making that possible for everyone.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">Certified healthcare professionals</p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">Personalized care plans</p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">24/7 availability</p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">Regular progress reporting</p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">Transparent pricing</p>
              </div>
              
              <div className="flex items-start">
                <CheckCircle2 size={20} className="text-primary mt-1 mr-2 flex-shrink-0" />
                <p className="text-gray-700">Insurance coordination</p>
              </div>
            </div>
            
            <button className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg font-medium transition-colors duration-300">
              Learn More About Us
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;