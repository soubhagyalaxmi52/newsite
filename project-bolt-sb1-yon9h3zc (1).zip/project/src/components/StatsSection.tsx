import React, { useState, useEffect } from 'react';

interface StatItemProps {
  value: number;
  label: string;
  suffix?: string;
  duration?: number;
}

const StatItem: React.FC<StatItemProps> = ({ 
  value, 
  label, 
  suffix = "", 
  duration = 2000 
}) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setIsVisible(true);
      }
    }, { threshold: 0.1 });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let start = 0;
    const end = value;
    const incrementTime = duration / end;
    const counter = setInterval(() => {
      start += 1;
      setCount(start);
      if (start >= end) clearInterval(counter);
    }, incrementTime);

    return () => {
      clearInterval(counter);
    };
  }, [value, duration, isVisible]);

  return (
    <div ref={ref} className="text-center">
      <p className="text-4xl md:text-5xl font-bold text-primary mb-2">
        {count}{suffix}
      </p>
      <p className="text-gray-600">{label}</p>
    </div>
  );
};

const StatsSection: React.FC = () => {
  return (
    <div className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-7xl mx-auto bg-gradient-to-r from-blue-500 to-primary rounded-xl overflow-hidden shadow-lg">
          <div className="px-6 py-12 md:p-12 bg-white bg-opacity-10 backdrop-blur-sm">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
              Our Impact in Numbers
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <StatItem value={500} label="Happy Patients" suffix="+" />
              <StatItem value={30} label="Healthcare Professionals" suffix="+" />
              <StatItem value={5} label="Years of Service" suffix="+" />
              <StatItem value={96} label="Satisfaction Rate" suffix="%" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsSection;