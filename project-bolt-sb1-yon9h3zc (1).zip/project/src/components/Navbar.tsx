import React, { useState, useEffect } from 'react';
import { Menu, X, PhoneCall } from 'lucide-react';
import { Link } from './Link';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-primary">CareComfort</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-800 hover:text-primary transition-colors">Home</Link>
            <Link href="/about" className="text-gray-800 hover:text-primary transition-colors">About Us</Link>
            <Link href="/services" className="text-gray-800 hover:text-primary transition-colors">Services</Link>
            <Link href="/testimonials" className="text-gray-800 hover:text-primary transition-colors">Testimonials</Link>
            <Link href="/careers" className="text-gray-800 hover:text-primary transition-colors">Careers</Link>
            <Link href="/contact" className="text-gray-800 hover:text-primary transition-colors">Contact</Link>
          </div>

          {/* Phone Button */}
          <div className="hidden md:flex items-center">
            <a href="tel:+919876543210" className="flex items-center bg-primary text-white px-4 py-2 rounded-full hover:bg-primary-dark transition-colors">
              <PhoneCall size={18} className="mr-2" />
              <span>Call Now</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-800 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden bg-white absolute top-full left-0 w-full shadow-md py-4 px-4 transition-all duration-300">
            <div className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Home</Link>
              <Link href="/about" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>About Us</Link>
              <Link href="/services" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Services</Link>
              <Link href="/testimonials" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Testimonials</Link>
              <Link href="/careers" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Careers</Link>
              <Link href="/contact" className="text-gray-800 hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Contact</Link>
              
              <a href="tel:+919876543210" className="flex items-center bg-primary text-white px-4 py-2 rounded-full hover:bg-primary-dark transition-colors w-fit">
                <PhoneCall size={18} className="mr-2" />
                <span>Call Now</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;