import React from 'react';
import { PhoneCall } from 'lucide-react';

const CallToAction: React.FC = () => {
  return (
    <div className="py-16 bg-primary">
      <div className="container mx-auto px-4 md:px-6 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started with Professional Home Care?
          </h2>
          
          <p className="text-white/90 text-lg mb-8">
            Contact us today for a free consultation. Our team is ready to create a personalized care plan for you or your loved one.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+919876543210" 
              className="bg-white text-primary hover:bg-gray-100 px-8 py-3 rounded-full font-medium transition-colors duration-300 flex items-center justify-center"
            >
              <PhoneCall size={18} className="mr-2" />
              <span>Call Now: +91 98765 43210</span>
            </a>
            
            <button 
              onClick={() => {
                const contactSection = document.getElementById('contact');
                if (contactSection) {
                  contactSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-3 rounded-full font-medium transition-colors duration-300"
            >
              Book a Free Consultation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CallToAction;