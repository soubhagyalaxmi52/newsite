import React from 'react';
import { ArrowRight } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, image }) => {
  return (
    <div className="group relative bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="absolute inset-0 bg-cover bg-center z-0 opacity-10 transition-opacity duration-300 group-hover:opacity-20"
           style={{ backgroundImage: `url(${image})` }}>
      </div>
      
      <div className="relative z-10 p-6">
        <div className="bg-blue-100 p-3 rounded-full w-fit mb-4">
          {icon}
        </div>
        
        <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
        <p className="text-gray-600 mb-5">{description}</p>
        
        <button className="flex items-center text-primary font-medium hover:text-primary-dark transition-colors">
          <span>Learn more</span>
          <ArrowRight size={16} className="ml-1 transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </div>
  );
};

export default ServiceCard;